<div class="col-md-6">
    <h3>Wine Flight Friday</h3>
    <p>Wine Flight Friday is hosted on the third Friday of the Month. Each month is themed by a region/state/country/continent. December 15 theme Italian - you can expect a White, and three Reds. Ticket for the flight is $25 per person.
        <br>
        <br>Reservations not required.​</p>

    <h3>Future Wine Flight Friday</h3>
    <p>​January 19<br>
        February 16<br>
    </p>

</div><!--end of md 6-->
<div class="col-md-6">
    <img src="assets/images/WFF.gif" style="width: 100%">
</div><!--end of md 6-->