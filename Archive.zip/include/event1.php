<div class="col-md-6">
    <h3>Wild Game Dinner</h3>
    <p>First Annual Wild Game Dinner
        Five Courses with wine pairing- featuring rabbit, boar, and elk. November 16, 2017, at 6:30 PM. Ticket price includes sales tax and gratuity.
        <br>
        Reservations Required</p>

    <a href="https://www.eventbrite.com/e/wild-game-dinner-tickets-39262119055" target="_blank">
        <input type="button" class="btn btn-default" value="RSVP" /></a> <br><br>

</div> <!--end of md 6-->
<div class="col-md-6">
    <img src="assets/images/web_wild_game.gif" style="width: 100%">
</div> <!--end of md 6-->