<!--<img src="/assets/images/K_Menu.pdf">-->

<!--<embed src="assets/images/K_Menu.pdf" width="100%" height="800px" type='application/pdf'>-->

<!--<iframe src="https://drive.google.com/file/d/0B7biVCjUgIlQQ0k3dmU5ZnV3eVU/preview" width="100%" height="480"></iframe>-->

<iframe src='https://onedrive.live.com/embed?cid=6DF4EAF32DB52C86&resid=6DF4EAF32DB52C86%21376&authkey=AK7iPULt3zDUSvY&em=2&wdStartOn=1' width="100%" height="600" frameborder='0'>This is an embedded <a target='_blank' href='https://office.com'>Microsoft Office</a> document, powered by <a target='_blank' href='https://office.com/webapps'>Office Online</a>.</iframe>