<!--<input type="button" value="Reservation" class="btn btn-danger" id="btnRes"
       onClick="document.location.href='reservations.php'" />-->

<a href="https://www.opentable.com/k-restaurant-reservations-orlando?restref=23929&lang=en-US" target="_blank" style="text-decoration: none">
    <input type="button" class="btn btn-danger" id="btnRes" value="Reservation" style="color: white;"/>

<a class="btn btn-danger" href="tel:1-407-872-2332" style="padding:6px; color: white;">
    Click to Call <span class="glyphicon glyphicon-earphone" style="padding-left:10px; padding-right:10px;"></span>407-872-2332
</a>