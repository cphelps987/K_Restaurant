

<footer class="footer">
    <div class="container">
        <div class="row">
            <div class="col-sm-2">
            </div>
            <div class="col-sm-8">
                <p class="text-mute footerBottom">K Restaurant 2017, 1710 Edgewater Dr, Orlando, FL 32804, (407) 872-2332</p>
            </div>
            <div class="col-sm-2">
                <p>
                    <a target="_blank" href="https://www.facebook.com/KRestaurantWineBar/" class="fa fa-facebook socialIcon"></a>
                    <a target="_blank" href="https://www.instagram.com/k_restaurantwinebar/" class="fa fa-instagram socialIcon"></a>
                    <a target="_blank" href="https://twitter.com/k_restaurant/" class="fa fa-twitter socialIcon"></a>
                </p>
            </div>
        </div>
    </div>
</footer>
