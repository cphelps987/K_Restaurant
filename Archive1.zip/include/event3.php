<div class="col-md-6">
    <h3>Truffle Dinner</h3>
    <p>Annual Truffle Dinner
        Five Courses with wine pairing- featuring truffles from Italy, France, and United States. December 4, 2017, at 6:30 PM. Ticket price includes sales tax and gratuity.
        <br>
        Reservations Required</p>

    <a href="https://www.eventbrite.com/e/truffle-dinner-tickets-39060767808" target="_blank">
        <input type="button" class="btn btn-default" value="RSVP" /></a> <br><br>

</div><!--end of md 6-->
<div class="col-md-6">
    <img src="assets/images/instagram_truffle.gif" style="width: 100%">
</div><!--end of md 6-->