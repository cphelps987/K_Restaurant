$( document ).ready(function() {

    $("#call").on('click', function() {
        var link = "tel:14078722332";
        window.location.href = link;
    });

});


